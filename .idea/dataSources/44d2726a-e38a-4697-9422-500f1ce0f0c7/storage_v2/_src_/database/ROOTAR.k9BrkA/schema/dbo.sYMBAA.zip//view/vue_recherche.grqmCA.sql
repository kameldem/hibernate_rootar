CREATE VIEW dbo.vue_recherche
AS
SELECT        dbo.PAYS.NOM_PAYS_FR, dbo.PAYS.NOM_PAYS_ANG, dbo.CONTINENT.ID_CONTINENT, dbo.CONTINENT.NOM_CONTINENT_FR, dbo.CONTINENT.NOM_CONTINENT_ANG, dbo.VILLE.ID_VILLE, dbo.VILLE.NOM_VILLE, 
                         dbo.THEMES.LIBELLE_THEME, dbo.THEMES.ID_THEME, dbo.AVOIR.ID_THEME AS ID_THEME_AVOIR, dbo.AVOIR.ID_PAYS, dbo.PAYS.ID_PAYS AS ID_PAYS_AVOIR, dbo.REGION.ID_REGION, dbo.REGION.NOM_REGION, 
                         dbo.PAYS.CODE_PAYS, dbo.PAYS.NATIONALITE, dbo.PAYS.NOMBRE_HABITANT, dbo.PAYS.SUPERFICIE, dbo.PAYS.DEVISE, dbo.PAYS.INDICATIF_TELEPHONIQUE, dbo.PAYS.FETE_NATIONALE, dbo.MONNAIE.ID_MONNAIE, 
                         dbo.MONNAIE.LIBELLE_MONNAIE
FROM            dbo.REGION RIGHT OUTER JOIN
                         dbo.MONNAIE INNER JOIN
                         dbo.CONTINENT INNER JOIN
                         dbo.PAYS ON dbo.CONTINENT.ID_CONTINENT = dbo.PAYS.ID_CONTINENT ON dbo.MONNAIE.ID_MONNAIE = dbo.PAYS.ID_MONNAIE LEFT OUTER JOIN
                         dbo.THEMES INNER JOIN
                         dbo.AVOIR ON dbo.THEMES.ID_THEME = dbo.AVOIR.ID_THEME ON dbo.PAYS.ID_PAYS = dbo.AVOIR.ID_PAYS ON dbo.REGION.ID_PAYS = dbo.PAYS.ID_PAYS RIGHT OUTER JOIN
                         dbo.VILLE ON dbo.REGION.ID_REGION = dbo.VILLE.ID_REGION
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[50] 4[11] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "VILLE"
            Begin Extent = 
               Top = 4
               Left = 905
               Bottom = 117
               Right = 1113
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "THEMES"
            Begin Extent = 
               Top = 312
               Left = 25
               Bottom = 408
               Right = 233
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "AVOIR"
            Begin Extent = 
               Top = 173
               Left = 143
               Bottom = 269
               Right = 351
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "CONTINENT"
            Begin Extent = 
               Top = 32
               Left = 39
               Bottom = 145
               Right = 257
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "PAYS"
            Begin Extent = 
               Top = 1
               Left = 394
               Bottom = 131
               Right = 626
            End
            DisplayFlags = 280
            TopColumn = 8
         End
         Begin Table = "REGION"
            Begin Extent = 
               Top = 123
               Left = 662
               Bottom = 253
               Right = 870
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "MONNAIE"
            Begin Extent = 
               Top = 6
               Left = 664
               Bottom = 102
               Right = 872
            End
            DisplayFlags = 280
       ', 'SCHEMA', 'dbo', 'VIEW', 'vue_recherche'
go

exec sp_addextendedproperty 'MS_DiagramPane2', N'     TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'vue_recherche'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 2, 'SCHEMA', 'dbo', 'VIEW', 'vue_recherche'
go

