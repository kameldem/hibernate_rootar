CREATE FUNCTION Password_Check4
	(
		@v1 varchar(500)
	)
	RETURNS  varchar(7)
	AS
	BEGIN
		DECLARE @result varchar(7)
 
 
	Select
		@result  =( CASE when [PASSWORD_USR] =  HASHBYTES('SHA2_512', @v1) THEN 'Valid'
			ELSE 'Invalid'
		END )
		from USR
		where  [ID_USR]=16
 
	RETURN @result
	END
go

