CREATE procedure [dbo].[SP_RECHERCHE]
	@choix varchar(500) ='',
	@nom varchar(30) = '',
	@pays int = 0,
	@continent int = 0,
	@ville int = 0,
	@theme int=0,
	@typeClimat int=0

AS
BEGIN
	DECLARE @REQUETE varchar(512)
	DECLARE @WHERE varchar(512)

	set @REQUETE = CONCAT ('SELECT distinct ',@choix,' from dbo.vue_recherche')
	if @nom is null set @nom = ''
	set @WHERE =CONCAT (' WHERE NOM_PAYS_FR like ''%' , @nom ,'%''')

	IF(@pays is not null and @pays !=0)
	set @where = concat(@where,' AND ID_PAYS = ',@pays)
	IF(@continent is not null and @continent !=0)
    set @where = concat(@where,' AND ID_CONTINENT = ',@continent)
	IF(@ville is not null and @ville !=0)
    set @where = concat(@where,' AND ID_VILLE = ',@ville)
	IF(@theme is not null and @theme !=0)
    set @where = concat(@where,' AND ID_THEMES = ',@theme)
	/*IF(@typeClimat is not null and @typeClimat !=0)
    set @where = concat(@where,' AND ID_TYPE_CLIMAT = ',@typeClimat)*/


execute (@REQUETE + @WHERE)
end
go

