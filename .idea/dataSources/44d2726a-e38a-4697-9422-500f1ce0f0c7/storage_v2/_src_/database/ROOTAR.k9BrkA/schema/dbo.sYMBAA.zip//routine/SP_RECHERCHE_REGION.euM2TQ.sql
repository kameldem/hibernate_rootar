create procedure [dbo].[SP_RECHERCHE_REGION]
	@nomRegion varchar(30) = ''
	

AS
BEGIN
	DECLARE @REQUETE varchar(512)
	DECLARE @WHERE varchar(512)

	set @REQUETE = 'SELECT * from dbo.vue_recherche_region'
	if @nomRegion is null set @nomRegion = ''
	set @WHERE =CONCAT (' WHERE NOM_REGION like ''%' , @nomRegion ,'%''')



execute (@REQUETE + @WHERE)
end
go

