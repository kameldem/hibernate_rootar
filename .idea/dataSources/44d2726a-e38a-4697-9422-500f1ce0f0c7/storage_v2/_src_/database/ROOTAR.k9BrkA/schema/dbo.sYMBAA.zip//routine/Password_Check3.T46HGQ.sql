CREATE FUNCTION Password_Check3
	(
		@v1 varchar(500)
	)
	RETURNS  varchar(7)
	AS
	BEGIN
		DECLARE @result varchar(7)
 
 
	Select
		@result  =( CASE when [NOM_USR] = @v1 THEN 'Valid'
			ELSE 'Invalid'
		END )
		from USR
		where  [ID_USR] = '15'
 
	RETURN @result
	END
go

