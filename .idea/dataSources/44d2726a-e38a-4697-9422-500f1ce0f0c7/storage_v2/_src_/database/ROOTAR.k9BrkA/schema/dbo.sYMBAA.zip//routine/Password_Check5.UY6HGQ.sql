 
CREATE FUNCTION Password_Check5
	(
		@v1 varchar(500)
	)
	RETURNS  varchar(7)
	AS
	BEGIN
		DECLARE @result varchar(7)
 
 
	Select
		@result  =( CASE when [PASSWORD_USR] =  HASHBYTES('SHA2_512', @v1) THEN 'Valid'
			ELSE 'Invalid'
		END )
		from USR
		where  [PASSWORD_USR] =  HASHBYTES('SHA2_512', @v1) 
 
	RETURN @result
	END
go

