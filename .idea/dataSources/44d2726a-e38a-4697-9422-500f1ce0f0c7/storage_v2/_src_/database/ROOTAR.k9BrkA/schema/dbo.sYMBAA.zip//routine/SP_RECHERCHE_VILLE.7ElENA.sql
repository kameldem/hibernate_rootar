create procedure [dbo].[SP_RECHERCHE_VILLE]
	@nomVille varchar(30) = ''
	

AS
BEGIN
	DECLARE @REQUETE varchar(512)
	DECLARE @WHERE varchar(512)

	set @REQUETE = 'SELECT * from dbo.vue_recherche_region'
	if @nomVille is null set @nomVille = ''
	set @WHERE =CONCAT (' WHERE NOM_VILLE like ''%' , @nomVille ,'%''')



execute (@REQUETE + @WHERE)
end

go

